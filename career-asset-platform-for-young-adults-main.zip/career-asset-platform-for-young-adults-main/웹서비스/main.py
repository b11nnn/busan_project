import os
import re
import math
import difflib
import pandas as pd
import numpy as np
from fastapi import FastAPI, Request, Form, HTTPException
from fastapi.responses import HTMLResponse, FileResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Dict
from dotenv import load_dotenv

# --- 환경설정 ---
load_dotenv()

app = FastAPI(title="일로온나 Career Matching API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory="."), name="static")

@app.get("/")
async def root():
    return RedirectResponse(url="/young_busan")

@app.get("/career")
async def read_career():
    with open("career.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

@app.get("/illo")
async def read_illo():
    with open("illo_service_page.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

@app.get("/young_busan")
async def read_young_busan():
    with open("young_busan_index_updated.html", "r", encoding="utf-8") as f:
        return HTMLResponse(content=f.read())

@app.get("/WN.js")
async def read_wn_js():
    return FileResponse("WN.js", media_type="application/javascript")

# 맵핑 데이터
SKILL_MAP = {"데이터/분석형": ["수리력", "논리적  분석", "산수와 수학", "경제와 회계", "기술 분석", "추리력"], "커뮤니케이션형": ["말하기", "설득", "협상", "상담", "영업과 마케팅", "고객서비스", "사람 파악"], "활동/엔지니어형": ["신체적  강인성", "기계", "정교한 동작", "장비의 유지", "조작 및 통제", "공간지각력", "안전과 보안", "장비 선정"], "문서/행정형": ["글쓰기", "읽고 이해하기", "국어", "사무", "기억력", "재정 관리", "인적자원 관리"], "기획/창의형": ["창의력", "예술", "디자인", "건축 및 설계", "의사소통과 미디어", "판단과 의사결정"], "IT/시스템형": ["전산", "컴퓨터와 전자공학", "공학과 기술", "고장의 발견.수리", "시스템"]}
ENV_MAP = {"실내 중심": ["실내", "앉아서", "사무실"], "실외/현장": ["실외", "현장", "야외", "이동"], "정적/사무": ["앉아서", "정적인", "집중력"], "동적/활동": ["서서", "육체적", "근력", "움직임"], "안전 우선": ["안전한", "쾌적한"], "위험 노출": ["위험한", "소음", "오염", "높은 곳"], "독립적": ["혼자", "독립", "개인"], "협력적": ["팀", "협동", "사람들과", "고객"], "규칙적": ["규칙적인", "주간", "일정한"], "유동적": ["불규칙", "출장", "교대", "야간"], "쾌적함": ["깨끗한", "냉난방"], "고부하(소음/열)": ["소음", "진동", "고온", "저온"]}

# 데이터 로드
try:
    df_jobs = pd.read_csv("final_merged_updatereal.csv").fillna("")
    if '직업명' not in df_jobs.columns and '직업소분류명' in df_jobs.columns: 
        df_jobs['직업명'] = df_jobs['직업소분류명']
    
    comp_file = "worknet_smlgnt_master_with_wage.csv"
    try:
        df_companies = pd.read_csv(comp_file, encoding='cp949').fillna("")
    except:
        try:
            df_companies = pd.read_csv(comp_file, encoding='utf-8').fillna("")
        except:
            df_companies = pd.read_csv(comp_file, encoding='utf-8-sig').fillna("")
    
    print("CSV 로딩 성공!")
except Exception as e:
    print(f"CSV 로딩 실패: {e}")
    df_jobs, df_companies = pd.DataFrame(), pd.DataFrame()

# --- Pydantic 데이터 모델 정의 ---
class MatchRequest(BaseModel):
    name: str; keyword: str; education: str; wage: int; burnout: str; company_size: str
    skills: List[str] = Field(default=[])
    envs: List[str] = Field(default=[])
    priorities: List[str] = Field(default=[])

class ExpertCoachRequest(BaseModel):
    user_name: str; user_skills: List[str]; target_job: str; target_region: str; wage: str; certs: str; prospect: str

class SimulationRequest(BaseModel):
    annual_salary_won: float
    goal_asset_man: float
    living_cost_man: float
    housing_cost_man: float
    comm_cost_man: float = 0
    selected_events: List[str] = []

class SimulateResult(BaseModel):
    feasible: bool
    months: int = None
    net_savings: float = None
    tax_bill: float = None
    insurance_bill: float = None
    disposable: float = None
    message: str = ""

# --- 유틸리티 함수 ---
def assign_region_by_job_name(job_name):
    busan_kws = ['소프트웨어', 'IT', '서비스', '기획', '디자인', '데이터', '금융', '마케팅', '플랫폼', '웹', '앱', '사무', '의료']
    ulsan_kws = ['자동차', '화학', '생산', '조립', '제조', '공정', '에너지', '환경', '품질', '섬유', '소재', '전지']
    gyeongnam_kws = ['항공', '우주', '기계', '선박', '조선', '로봇', '설비', '메카트로닉스', '용접', '부품', '금형']
    
    for kw in ulsan_kws:
        if kw in str(job_name): return '울산 (영남공업벨트/현대계열)'
    for kw in gyeongnam_kws:
        if kw in str(job_name): return '경남 (진주혁신도시/기계공업)'
    for kw in busan_kws:
        if kw in str(job_name): return '부산 (IT/센텀시티/금융단지)'
        
    hash_val = hash(job_name) % 3
    if hash_val == 0: return '부산 (센텀/기장 테크노밸리)'
    elif hash_val == 1: return '울산 (미포/온산공단)'
    else: return '경남 (창원/진해신항)'

def format_salary(salary_str):
    try:
        num = int(re.sub(r'[^0-9]', '', str(salary_str)))
        if num > 0:
            if num >= 1000000:
                num = num // 10000
            if num >= 10000:
                return f"{num // 10000}억 {num % 10000 if num % 10000 != 0 else ''}만원"
            return f"{num:,}만원"
    except: pass
    return "회사 내규에 따름"

def parse_dict(s_str, t_str):
    return {t.strip(): float(s) for s, t in zip(str(s_str).split(','), str(t_str).split(',')) if s.strip() and t.strip()}

# --- API 엔드포인트 ---
@app.post("/api/match")
async def match_career(req: MatchRequest):
    if df_jobs.empty: raise HTTPException(500, "직업 데이터가 로드되지 않았습니다.")
    
    edu_map = {
        "고등학교 졸업": ["학력분포(%) : 고졸"], 
        "전문대 졸업": ["학력분포(%) : 고졸", "학력분포(%) : 전문대졸"], 
        "대학교 졸업": ["학력분포(%) : 고졸", "학력분포(%) : 전문대졸", "학력분포(%) : 대졸"], 
        "석사 졸업": ["학력분포(%) : 고졸", "학력분포(%) : 전문대졸", "학력분포(%) : 대졸", "학력분포(%) : 대학원졸"], 
        "박사 졸업": ["학력분포(%) : 고졸", "학력분포(%) : 전문대졸", "학력분포(%) : 대졸", "학력분포(%) : 대학원졸", "학력분포(%) : 박사졸"]
    }
    relevant = edu_map.get(req.education, ["대학교 졸업"])
    filtered_df = df_jobs.copy()
    
    avail_cols = [c for c in relevant if c in filtered_df.columns]
    if avail_cols:
        for col in avail_cols: filtered_df[col] = pd.to_numeric(filtered_df[col].astype(str).str.replace('%',''), errors='coerce').fillna(0)
        filtered_df["사용자학력_누적비율"] = filtered_df[avail_cols].sum(axis=1)
    else: filtered_df["사용자학력_누적비율"] = 100

    wage_col = "임금_만원" if "임금_만원" in filtered_df.columns else "평균임금"
    clean_wage = filtered_df[wage_col].astype(str).str.replace(',', '').str.extract(r'(\d+)')[0]
    filtered_df["임금_숫자"] = pd.to_numeric(clean_wage, errors='coerce').fillna(0)
    
    pass_mask = (filtered_df["사용자학력_누적비율"] >= 10) & (filtered_df["임금_숫자"] >= (req.wage * 0.8))
    filtered_df = filtered_df[pass_mask].copy().reset_index(drop=True)
    
    if filtered_df.empty: raise HTTPException(404, "No Match Found")

    def calc_score(row):
        total = 0
        job_name, summary = str(row.get('직업명', '')), str(row.get('직업요약', ''))
        sim = difflib.SequenceMatcher(None, req.keyword, job_name).ratio() * 100
        strict = max(sim, difflib.SequenceMatcher(None, req.keyword, summary).ratio() * 100)
        total += strict * 0.3

        comb_skills = {**parse_dict(row.get('직업 간 비교 업무수행능력 수준 : 중요도(0:낮음 ~ 100:높음)', ''), row.get('직업 간 비교 업무수행능력 수준 : 업무수행능력', '')), 
                       **parse_dict(row.get('직업 간 비교 지식중요도 : 중요도(0:낮음 ~ 100:높음)', ''), row.get('직업 간 비교 지식중요도 : 업무수행능력', ''))}
        
        sk_sum = sum(max([score for txt, score in comb_skills.items() if any(kw in txt for kw in SKILL_MAP.get(us, []))] or [0]) for us in req.skills)
        if req.skills: total += (sk_sum / (len(req.skills) * 100)) * 15

        env_dict = parse_dict(row.get('직업 간 비교 업무환경 : 중요도(0:낮음 ~ 100:높음)', ''), row.get('직업 간 비교 업무환경 : 업무환경', ''))
        env_sum = sum(max([score for txt, score in env_dict.items() if any(kw in txt for kw in ENV_MAP.get(ue, []))] or [0]) for ue in req.envs)
        if req.envs: total += (env_sum / (len(req.envs) * 100)) * 10
        
        stress_kws = ["위험", "갈등", "경쟁", "소음", "더운", "추운", "무례한", "불쾌", "비좁은", "마감시간", "속도에 보조", "오염", "반복적인", "책임", "압박"]
        relax_kws = ["실내", "앉아서", "규칙적인", "재택", "안전한"]
        
        stress_score_sum = sum(score for txt, score in env_dict.items() if any(kw in txt for kw in stress_kws))
        relax_score_sum = sum(score for txt, score in env_dict.items() if any(kw in txt for kw in relax_kws))

        norm_stress = min(100, stress_score_sum / 3)
        norm_relax = min(100, relax_score_sum / 2)
        
        sati_score = float(row.get("만족도_num", 70))
        if pd.isna(sati_score): sati_score = 70
        
        burnout_score, wage_val = 0, float(row.get("임금_숫자", 0))
        
        if req.burnout == "고위험":
            burnout_score = ((100 - norm_stress) / 100) * 20 + (norm_relax / 100) * 15
        elif req.burnout == "주의":
            burnout_score = ((100 - norm_stress) / 100) * 15 + (sati_score / 10) * 20
        else: 
            burnout_score = (sati_score / 10) * 20 + min(15, wage_val / 1000) * 4
            
        total += min(35, max(0, burnout_score))
        
        weights = [18, 10, 5, 1]
        for i, prio in enumerate(req.priorities[:4]):
            w = weights[i]
            if prio == "major":
                total += (strict / 100) * w
            elif prio == "salary":
                if req.wage <= 0:
                    total += w
                elif wage_val >= req.wage * 1.2:
                    total += w
                elif wage_val >= req.wage:
                    total += w * 0.75
                elif wage_val >= req.wage * 0.9:
                    total += w * 0.4
                elif wage_val >= req.wage * 0.7:
                    total += w * 0.1
            elif prio == "worklife":
                total += (norm_relax / 100) * w if req.envs else (norm_relax / 100) * w * 0.5
            elif prio == "satisfaction":
                total += (sati_score / 100) * w
        
        return total
    
    filtered_df['match_score'] = filtered_df.apply(calc_score, axis=1) + np.random.rand(len(filtered_df))
    top_jobs = filtered_df.sort_values(by='match_score', ascending=False).head(3)

    res_jobs = []
    for _, job in top_jobs.iterrows():
        t_region = assign_region_by_job_name(job['직업명'])
        region_kw = t_region.split(' ')[0]
        
        job_comps = []
        if not df_companies.empty:
            search_pattern = "|".join([job['직업명'][:2], req.keyword[:2]])
            comp_mask = df_companies['주요생산품목'].str.contains(search_pattern, na=False)
            local_mask = df_companies['지역명'].str.contains(region_kw, regex=False, na=False)
            
            matched = df_companies[local_mask & comp_mask].head(3)
            if len(matched) < 3:
                matched = pd.concat([matched, df_companies[local_mask].head(3 - len(matched))])
            
            for _, comp in matched.iterrows():
                clean_name = re.sub(r'\(주\)|주식회사|합자회사|\(사\)|사단법인', '', str(comp.get('회사명', ''))).strip()
                raw_address = str(comp.get('주소', str(comp.get('주소 ', region_kw))))
                parts = raw_address.split()
                short_location = " ".join(parts[:2]) if len(parts) >= 2 else raw_address

                raw_workers = str(comp.get('상시근로자 수', comp.get('근로자수', comp.get('기업규모', '규모 정보 없음')))).replace('명', '').strip()
                try:
                    worker_count = f"{int(float(raw_workers))}명"
                except:
                    worker_count = raw_workers

                job_comps.append({
                    "name": str(comp.get('기업명', '')),
                    "name_clean": clean_name,
                    "brand": str(comp.get('강소기업브랜드명', '')).strip(),
                    "location": short_location,
                    "business": str(comp.get('주요사업내용', str(comp.get('주요사업 ', '연관 산업')))),
                    "salary": format_salary(comp.get('초봉', '')),
                    "workers": worker_count
                })

        wage_str = str(job.get('임금_중앙값', job.get('평균임금', '0')))
        clean_wage_num = int(re.sub(r'[^0-9]', '', wage_str)) if re.sub(r'[^0-9]', '', wage_str) else 0
        if clean_wage_num >= 1000000:
            clean_wage_num = clean_wage_num // 10000
        wage_formatted = f"{clean_wage_num:,}만원" if clean_wage_num > 0 else "연봉 정보 없음"
        
        job['radar_0'] = min(100, (clean_wage_num / (req.wage or 1)) * 100) if req.wage else 70
        job['radar_1'] = float(job.get('직업만족도(%)', job.get('만족도_num', '70')) or 70)
        job['radar_2'] = 85 if '증가' in str(job.get('일자리전망', '')) else (60 if '감소' in str(job.get('일자리전망', '')) else 75)

        comb_skills_r = {**parse_dict(job.get('직업 간 비교 업무수행능력 수준 : 중요도(0:낮음 ~ 100:높음)', ''), job.get('직업 간 비교 업무수행능력 수준 : 업무수행능력', '')), 
                       **parse_dict(job.get('직업 간 비교 지식중요도 : 중요도(0:낮음 ~ 100:높음)', ''), job.get('직업 간 비교 지식중요도 : 업무수행능력', ''))}
        sk_sum_r = sum(max([score for txt, score in comb_skills_r.items() if any(kw in txt for kw in SKILL_MAP.get(us, []))] or [0]) for us in req.skills)
        
        env_dict_r = parse_dict(job.get('직업 간 비교 업무환경 : 중요도(0:낮음 ~ 100:높음)', ''), job.get('직업 간 비교 업무환경 : 업무환경', ''))
        env_sum_r = sum(max([score for txt, score in env_dict_r.items() if any(kw in txt for kw in ENV_MAP.get(ue, []))] or [0]) for ue in req.envs)
        
        relax_kws_r = ["실내", "앉아서", "규칙적인", "재택", "안전한"]
        relax_score_sum_r = sum(score for txt, score in env_dict_r.items() if any(kw in txt for kw in relax_kws_r))
        norm_relax_r = min(100, relax_score_sum_r / 2)
        
        job['radar_3'] = min(100, (sk_sum_r + env_sum_r) / 2) if req.skills and req.envs else (sk_sum_r if req.skills else (env_sum_r if req.envs else 80))
        job['radar_4'] = norm_relax_r

        res_jobs.append({
            "name": job['직업명'],
            "category": t_region,
            "region": region_kw,
            "score": min(100, int(job['match_score'])),
            "wage": wage_formatted,
            "summary": str(job.get('직업요약', '수행 직무 정보가 없습니다.')),
            "satisfaction": str(job.get('직업만족도(%)', job.get('만족도_num', '70'))).replace('.0', ''),
            "outlook": str(job.get('일자리전망률', job.get('일자리전망', '유지'))).split(',')[0],
            "major": str(job.get('가장 높은 비율 전공', '정보 없음')),
            "certs": str(job.get('관련자격명', '특별한 우대 자격증 없음')) or '특별한 우대 자격증 없음',
            "companies": job_comps,
            "radar_0": job.get('radar_0', 70),
            "radar_3": job.get('radar_3', 80),
            "radar_4": job.get('radar_4', 70)
        })
    
    if not res_jobs:
        return {"user_name": req.name, "radar_scores": [0, 0, 0, 0, 0], "jobs": []}
    
    r0 = sum(j.get("radar_0", 70) for j in res_jobs) / max(len(res_jobs), 1) if "radar_0" in res_jobs[0] else min(100, (req.wage/3000)*100)
    r1 = sum(float(str(j.get("satisfaction", 70)).replace(" ","")) or 70 for j in res_jobs) / max(len(res_jobs), 1)
    
    r2 = 0
    for j in res_jobs:
        if "증가" in str(j.get("outlook", "")): r2 += 90
        elif "감소" in str(j.get("outlook", "")): r2 += 60
        else: r2 += 75
    r2 = r2 / max(len(res_jobs), 1)
    r3 = sum(j.get("radar_3", 80) for j in res_jobs) / max(len(res_jobs), 1)
    r4 = sum(j.get("radar_4", 70) for j in res_jobs) / max(len(res_jobs), 1)
    
    return {"user_name": req.name, "radar_scores": [int(r0), int(r1), int(r2), int(r3), int(r4)], "jobs": res_jobs}

# --- 소망 기업 찾기 ---
@app.get("/api/search-company")
async def search_company(q: str):
    if df_companies.empty or "기업명" not in df_companies.columns:
        return {"hits": []}
    
    ql = q.lower().replace(" ", "").replace("(주)", "").replace("주식회사", "").replace("(사)", "").replace("사단법인", "")
    mask = (
        df_companies["기업명"].str.lower().str.replace(" ", "").replace(r"\(주\)|주식회사|합자회사|\(사\)|사단법인", "", regex=True).str.contains(ql, na=False) |
        df_companies.get("주요생산품목", pd.Series([False]*len(df_companies))).str.lower().str.contains(ql, na=False)
    )
    hits = df_companies[mask].head(20)
    results = []
    for _, r in hits.iterrows():
        results.append({
            "name": str(r.get("기업명", "")),
            "business": str(r.get("산업분류명", str(r.get("강소기업브랜드명", "기본")))),
            "location": str(r.get("지역명", str(r.get("주소", "부산")))).split()[0] if str(r.get("지역명", str(r.get("주소", "부산")))) else "부산",
            "salary": int(float(str(r.get("초봉", 3000)).replace("원","").strip() or 30000000)) // 10000,
            "workers": int(float(str(r.get("상시근로자 수", 0)).replace("명","").strip() or 0)),
            "org": "corp",
            "size": "m"
        })
    return {"hits": results}

# --- 맞춤 코칭 리포트 API ---
@app.post("/api/expert-coach")
async def expert_coach(req: ExpertCoachRequest):
    job = req.target_job
    region = req.target_region
    
    if 'IT' in job or '소프트웨어' in job or '개발' in job or '데이터' in job:
        advice = f"IT/소프트웨어 직무는 트렌드 변화가 빠릅니다. {region} 지역의 강소기업들을 타겟으로 포트폴리오를 점검하세요."
    elif '생산' in job or '제조' in job or '기계' in job or '엔지니어' in job or '품질' in job:
        advice = f"{region} 지역은 우수한 제조업 기반의 강소기업이 많습니다. 실무 자격증 취득과 현장 기술 숙련도를 이력서에 어필하는 것이 유리합니다."
    elif '디자인' in job or '마케팅' in job or '기획' in job:
        advice = f"{job} 분야는 실무 감각과 크리에이티브가 중요합니다. 지원하고자 하는 {region} 지역 기업들의 최근 프로젝트를 분석하여 선제적으로 포트폴리오를 만들어보세요."
    elif '서비스' in job or '영업' in job or '고객' in job:
        advice = f"고객 중심의 커뮤니케이션 역량이 핵심입니다. 이전 경험에서 갈등을 해결하거나 실무적인 성과에 기여했던 구체적인 사례를 어필하세요."
    else:
        advice = f"{job} 분야에서 기본기를 탄탄히 하고 관련 교육을 꾸준히 이수한다면, {region} 지역의 우수 강소기업에서 반드시 좋은 기회를 얻을 수 있습니다."

    return {"text": f"[맞춤형 전문가 분석]\\n{req.user_name}님, {advice}"}

# --- 재산 시뮬레이션 데이터 관리 ---
TAX_RAW = [
    [700, 0], [750, 0], [800, 0], [850, 0], [900, 0], [950, 0], [1000, 0], [1050, 0], [1100, 0], [1150, 0], [1200, 0], [1250, 0], [1300, 0], [1350, 0], [1400, 0], [1450, 0], [1500, 0], [1550, 0], [1600, 0], [1650, 0], [1700, 0], [1750, 0], [1800, 0], [1850, 0], [1900, 0], [1950, 0], [2000, 0], [2050, 0], [2100, 0], [2150, 0], [2200, 0], [2250, 0], [2300, 0], [2350, 0], [2400, 0], [2450, 0], [2500, 0], [2550, 0], [2600, 0], [2650, 0], [2700, 0], [2750, 0], [2800, 0], [2850, 0], [2900, 0], [2950, 0],
    [3000, 1400], [3050, 1710], [3100, 1800], [3150, 1825], [3200, 1832], [3250, 1939], [3300, 1946], [3350, 1953], [3400, 2060], [3450, 2067], [3500, 2074], [3550, 2181], [3600, 2188], [3650, 2220], [3700, 2290], [3750, 2361], [3800, 2432], [3850, 2503], [3900, 2574], [3950, 2645], [4000, 2716], [4050, 2787], [4100, 2858], [4150, 2929], [4200, 3000], [4250, 3071], [4300, 3142], [4350, 3213], [4400, 3284], [4450, 3355], [4500, 3426], [4550, 3497], [4600, 3568], [4650, 3639], [4700, 3710], [4750, 3781], [4800, 3852], [4850, 3923], [4900, 3994], [4950, 4065], [5000, 4136], [5050, 4207], [5100, 4278], [5150, 4349], [5200, 4420], [5250, 4491], [5300, 4562], [5350, 4633], [5400, 4704], [5450, 4775], [5500, 4846], [5550, 4917], [5600, 4988], [5650, 5059], [5700, 5130], [5750, 5201], [5800, 5272], [5850, 5343], [5900, 5414], [5950, 5485], [6000, 5556], [6050, 5627], [6100, 5698], [6150, 5769], [6200, 5840], [6250, 5911], [6300, 5982], [6350, 6053], [6400, 6124], [6450, 6195], [6500, 6266], [6550, 6337], [6600, 6408], [6650, 6479], [6700, 6550], [6750, 6621], [6800, 6692], [6850, 6763], [6900, 6834], [6950, 6905], [7000, 7100], [7050, 7171], [7100, 7242], [7150, 7313], [7200, 7384], [7250, 7455], [7300, 7526], [7350, 7597], [7400, 7668], [7450, 7739], [7500, 7810], [7550, 7881], [7600, 7952], [7650, 8023], [7700, 8104], [7750, 8185], [7800, 8266], [7850, 8347], [7900, 8428], [7950, 8509], [8000, 8590], [8050, 8617], [8100, 8744], [8150, 8871], [8200, 8998], [8250, 9125], [8300, 9252], [8350, 9379], [8400, 9506], [8450, 9633], [8500, 9760], [8550, 9887], [8600, 10014], [8650, 10141], [8700, 10268], [8750, 10395], [8800, 10522], [8850, 10649], [8900, 10776], [8950, 10903], [9000, 11030], [9050, 11157], [9100, 11284], [9150, 11411], [9200, 11538], [9250, 11665], [9300, 11792], [9350, 11919], [9400, 12046], [9450, 12173], [9500, 12300], [9550, 12437], [9600, 12574], [9650, 12711], [9700, 12848], [9750, 12985], [9800, 13122], [9850, 13259], [9900, 13396], [9950, 13533], [10000, 13670], [10100, 13944], [10200, 14218], [10300, 14492], [10400, 14766], [10500, 15040], [10600, 15314], [10700, 15588], [10800, 15862], [10900, 16136], [11000, 16410], [11100, 16684], [11200, 16958], [11300, 17232], [11400, 17506], [11500, 17780], [11600, 18054], [11700, 18328], [11800, 18602], [11900, 18876], [12000, 19150], [12100, 19424], [12200, 19698], [12300, 19972], [12400, 20246], [12500, 20520], [12600, 20794], [12700, 21068], [12800, 21342], [12900, 21616], [13000, 21890], [13100, 22164], [13200, 22438], [13300, 22712], [13400, 22986], [13500, 23260], [13600, 23534], [13700, 23808], [13800, 24082], [13900, 24356], [14000, 24630], [14100, 24904], [14200, 25178], [14300, 25452], [14400, 25726], [14500, 26000], [14600, 26274], [14700, 26548], [14800, 26822], [14900, 27096], [15000, 27370], [15100, 27644], [15200, 27918], [15300, 28192], [15400, 28466], [15500, 28740], [15600, 29014], [15700, 29288], [15800, 29562], [15900, 29836], [16000, 30110], [16100, 30384], [16200, 30658], [16300, 30932], [16400, 31206], [16500, 31480], [16600, 31754], [16700, 32028], [16800, 32302], [16900, 32576], [17000, 33070], [17100, 33385], [17200, 33700], [17300, 34015], [17400, 34330], [17500, 34645], [17600, 34960], [17700, 35275], [17800, 35590], [17900, 35905], [18000, 36220], [18100, 36535], [18200, 36850], [18300, 37165], [18400, 37480], [18500, 37795], [18600, 38110], [18700, 38425], [18800, 38740], [18900, 39055], [19000, 39370], [19100, 39685], [19200, 40000], [19300, 40315], [19400, 40630], [19500, 40945], [19600, 41260], [19700, 41575], [19800, 41890], [19900, 42205], [20000, 42520], [21000, 45670], [22000, 48820], [23000, 51970], [24000, 55120], [25000, 58270], [26000, 61420], [27000, 64570], [28000, 67720], [29000, 70870], [30000, 74020], [31000, 77170], [32000, 80320], [33000, 83470], [34000, 86620], [35000, 89770], [36000, 92920], [37000, 96070], [38000, 99220], [39000, 102370], [40000, 105520], [41000, 108670], [42000, 111820], [43000, 114970], [44000, 118120], [45000, 121270], [46000, 124420], [47000, 127570], [48000, 130720], [49000, 133870], [50000, 137020], [51000, 140410], [52000, 143800], [53000, 147190], [54000, 150580], [55000, 153970], [56000, 157360], [57000, 160750], [58000, 164140], [59000, 167530], [60000, 170920], [61000, 174310], [62000, 177700], [63000, 181090], [64000, 184480], [65000, 187870], [66000, 191260], [67000, 194650], [68000, 198040], [69000, 201430], [70000, 204820], [71000, 208210], [72000, 211600], [73000, 214990], [74000, 218380], [75000, 221770], [76000, 225160], [77000, 228550], [78000, 231940], [79000, 235330], [80000, 238720]
]

def find_tax(monthly_gross_man: float) -> float:
    monthly_k = round(monthly_gross_man * 10)  # Convert man won to cheon won
    if monthly_k < TAX_RAW[0][0]:
        return 0.0
    tax_val = TAX_RAW[-1][1]
    for bracket in TAX_RAW:
        if monthly_k < bracket[0]:
            break
        tax_val = bracket[1]
    return tax_val / 10000.0  # return man won

@app.post("/api/simulate", response_model=SimulateResult)
async def run_simulate_endpoint(req: SimulationRequest):
    monthly_gross_man = (req.annual_salary_won / 12) / 10000.0
    
    # 1. 4대보험 (9.4015%)
    insurance_rate = 0.094
    insurance_bill_man = monthly_gross_man * insurance_rate
    
    # 2. 근로소득세 (간이세액표 기준)
    tax_bill_man = find_tax(monthly_gross_man)

    disposable_man = monthly_gross_man - insurance_bill_man - tax_bill_man

    # 3. 추가 라이프 이벤트 비용 처리
    event_monthly = 0
    event_once = 0
    LIFE_EVENTS = {
        "car": {"cost_once": 2500, "cost_monthly": 35},
        "marriage": {"cost_once": 2500, "cost_monthly": 0},
        "loan": {"cost_once": 0, "cost_monthly": 30},
        "parents": {"cost_once": 0, "cost_monthly": 5},
        "medical": {"cost_once": 0, "cost_monthly": 8}
    }
    for ev in req.selected_events:
        if ev in LIFE_EVENTS:
            event_monthly += LIFE_EVENTS[ev]["cost_monthly"]
            event_once += LIFE_EVENTS[ev]["cost_once"]

    fixed_cost = req.housing_cost_man + req.comm_cost_man
    net_savings = disposable_man - fixed_cost - req.living_cost_man - event_monthly

    if net_savings <= 0:
        return SimulateResult(
            feasible=False,
            net_savings=round(net_savings, 1),
            tax_bill=round(tax_bill_man, 1),
            insurance_bill=round(insurance_bill_man, 1),
            disposable=round(disposable_man, 1),
            message="매달 숨만 쉬어도 마이너스인 계획입니다."
        )

    total_goal = req.goal_asset_man + event_once
    months = math.ceil(total_goal / net_savings)

    return SimulateResult(
        feasible=True,
        months=months,
        net_savings=round(net_savings, 1),
        tax_bill=round(tax_bill_man, 1),
        insurance_bill=round(insurance_bill_man, 1),
        disposable=round(disposable_man, 1)
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)